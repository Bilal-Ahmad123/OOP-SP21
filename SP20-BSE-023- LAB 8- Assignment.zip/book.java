/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner9;

/**
 *
 * @author Bilal
 */
public class book extends Publication
{
    
    protected  int count;

    public void setCount(int count) {
       this.count=count;
    }

    public int getCount() {
        return count;
    }
    
    @Override
    public void display(){
        System.out.println(" price of book "+this.getPrice()+
"\n title of book is "+this.getTitle()+
"\n Page count "+this.getCount());
        super.display();
    }
    
  
    
}
