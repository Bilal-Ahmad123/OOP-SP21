package runner9;
import java.util.Scanner;



/**
 *
 * @author Bilal
 */
public class Runner9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input=new Scanner(System.in);
        tape t1=new tape();
        book b1=new book();
        
        
        System.out.print("Enter the title of book :");
        String title;
        title=input.next();
        b1.settittle(title);
        
        
        System.out.print("Enter the price of book :");
        int price;
        price=input.nextInt();
        b1.setprice(price);
        
        
        System.out.print("Enter the book page count :");
        int count;
        count=input.nextInt();
        b1.setCount(count);
        
        
         System.out.print("Enter the name of audio casette :");
        String name;
        name=input.next();
       t1.settittle(name);
       
        
       System.out.print("Set the playing time for audio casette :");
       int audio;
       audio =input.nextInt();
       t1.setPlaying_time(audio);
       
       
       System.out.print("Enter the price of the audio casette :");
       int casette;
       casette=input.nextInt();
       t1.setprice(casette);
       
b1.display();
        t1.display();

        
                
    }
    
    
}
