    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
    package runner9;

    /**
     *
     * @author Bilal
     */
    public class tape extends Publication {

        protected  int playing_time;



        public void setPlaying_time(int playing_time) {
           this.playing_time=playing_time;
        }


        public int getPlaying_time() {
            return playing_time;
        }

        /**
         *
         */
        @Override
        public void display(){
           System.out.println(" price of tape "+this.getPrice()+
    "\n title of tape is "+this.getTitle()+
    "\n minutes palying "+this.getPlaying_time());
        }
        }


    }
