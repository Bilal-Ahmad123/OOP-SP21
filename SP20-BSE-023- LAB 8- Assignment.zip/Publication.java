/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner9;

/**
 *
 * @author Bilal
 */
public class Publication {
    
    protected String title;
    protected int price;
    
    
    public void settittle(String title){
        this.title=title;

    }
    
    public void setprice(int price){
        this.price=price;
    }

    public String getTitle() {
        return title;
    }

    public int getPrice() {
        return price;
    }
    
    public void display(){
        
 
    
        
    }
    
}
