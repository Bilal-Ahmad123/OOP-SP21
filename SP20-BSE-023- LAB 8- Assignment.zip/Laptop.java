/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner10;

/**
 *
 * @author Bilal
 */
public class Laptop extends Computer{
    
    public int height;
    public int width;
    public int length;
    public int weight;
    
    public Laptop(){
        super();
        
    }
  
     public Laptop(int height,int width,int length,int weight){
         this.height=height;
         this.length=length;
         this.weight=weight;
         this.width=width;
         
     }
    @Override
    public void display(){
        System.out.println("length of the laptop is "+length+" height of the laptop is "+height+" width of the laptop is "+
                width+" weight of the laptop is "+weight);
        super.display();
    }
    
}
