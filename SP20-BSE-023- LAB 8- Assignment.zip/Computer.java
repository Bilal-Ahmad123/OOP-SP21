/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner10;

/**
 *
 * @author Bilal
 */
public class Computer {
   public int memory_size;
   public int storage_size;
   public int speed;
    
   public Computer(){
       this(4,5,6);
   }
   
   
   public Computer(int memory_size,int storage_size,int speed){
       this.storage_size=storage_size;
       this.memory_size=memory_size;
       this.speed=speed;
   }
   
   
   public void display(){
       System.out.println("Memory size of the computer is "+memory_size+" storage size of the computer is "+storage_size
       +" speed of the computer is "+speed);
   }
   
   
}
