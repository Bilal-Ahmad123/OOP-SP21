
package student;

/**
 *
 * @author Bilal
 */
public class Runner {

    
    public static void main(String[] args) {
        
       PhdStudent p=new PhdStudent();
       System.out.println(p.TakeExam());
       
       GradStudent g=new GradStudent();
              System.out.println(g.TakeExam());
              
    }
    
}
