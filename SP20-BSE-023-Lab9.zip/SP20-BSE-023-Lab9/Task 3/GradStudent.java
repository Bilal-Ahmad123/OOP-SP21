
package student;

/**
 *
 * @author Bilal
 */
public class GradStudent extends Student{
    
    @Override
    public String TakeExam(){
        return "graduate student gives a written paper.";
    }
    
    
}
