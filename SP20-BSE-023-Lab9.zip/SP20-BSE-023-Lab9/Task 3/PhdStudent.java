
package student;

/**
 *
 * @author Bilal
 */
public class PhdStudent extends Student{
    
    @Override
    public String TakeExam(){
        return "takes exam by giving his final defense presentation";
    }
}
