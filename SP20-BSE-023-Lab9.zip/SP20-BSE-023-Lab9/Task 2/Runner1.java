/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass;

/**
 *
 * @author Bilal
 */
public class Runner1 {
    
    public static void main(String args[]){
        
         StringTokenizer st=new StringTokenizer(9);
        st.counttokens();
        
       
        Count ct=new Count();
        ct.counttokens();
        ct.disp();
    }
    
}
