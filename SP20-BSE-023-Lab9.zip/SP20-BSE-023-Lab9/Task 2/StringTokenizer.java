/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass;

/**
 *
 * @author Bilal
 */
public class StringTokenizer {
    
    int counttokens;
    
    public StringTokenizer(){
        this.counttokens=0;
    }
    
    public StringTokenizer(int counttokens){
        this.counttokens=counttokens;
    }
    
    public void counttokens(){
        counttokens++;
    }
    
    public void setrcounttokens(int counttokens){
        this.counttokens=counttokens;
    }
    
    public int gettokens(){
        return counttokens;
        
    }
    public void disp(){
        System.out.print("Counttokens "+counttokens);
    }
    
    
}
