/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass;

/**
 *
 * @author Bilal
 */
public class Time extends Clock{
    
    
    
    public Time(){
        hours=0;
        mins=0;
        sec=0;
    }
    
    public Time(int hours,int mins,int sec){
        this.hours=hours;
        this.mins=mins;
        this.sec=sec;
        
    }
            @Override
    public void display(){
        System.out.print(hours+":"+mins+":"+":");
        if (hours>12){
        System.out.println(hours-12+" :"+mins+" PM");
        }
        else{
            System.out.print(hours+":"+mins+" AM");
        }
        
    }
   
}
