
package pkgclass;

import java.util.*;
public class Runner {

    
    public static void main(String[] args) {
       
        Scanner input=new Scanner(System.in);
        
        System.out.print("Enter the hours :");
        int hours;
        hours=input.nextInt();
        
        System.out.print("Enter the Minutes :");
        int mins;
        mins=input.nextInt();
        
        System.out.print("Enter the seconds :");
        int sec;
        sec=input.nextInt();
        
        Clock c=new Clock(hours,mins,sec);
   Time t=new Time(14,45,55);
            
        
        if(c.check(hours, mins, sec)){
            System.out.print("The time you enterd is correct");
            t.display();
            
       
        }
        else{
            System.out.println("The time you entered is incorrect");
        }
        
    
    }
}
