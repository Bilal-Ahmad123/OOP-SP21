/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgclass;

/**
 *
 * @author Bilal
 */
public class Clock {
    
    
     int hours,mins,sec;
     
     public Clock(){
         hours=0;
         mins=0;
         sec=0;
     }
    public Clock(int hours,int mins,int sec){
        this.hours=hours;
        this.mins=mins;
        this.sec=sec;
       
        
    }
    
    
    public void sethours(int hours){
        this.hours=hours;
    }
    
    public void setmins(int mins){
        this.mins=mins;
    }
    
    public void setsec(int sec){
        this.sec=sec;
    }

    public boolean check(int hours,int mins,int sec){
        
        if(hours<=24 && mins<=60 && sec<=60){
            return true;
        }
        return false;
    }
    
     public void display(){
        System.out.print(hours+":"+mins+":"+sec+":");
    }
    
}
