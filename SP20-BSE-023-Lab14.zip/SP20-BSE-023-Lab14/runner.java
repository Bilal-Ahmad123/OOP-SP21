
package lab14;

import java.util.Scanner;
import java.io.*;


public class runner {
           
 

   
    public static void main(String[] args) throws FileNotFoundException, IOException {
             int account_no,amount;
             Scanner input=new Scanner(System.in);
          
           ObjectOutputStream write=new ObjectOutputStream(new FileOutputStream("E://filename.txt"));


Account ac[]=new Account[5];
Account a=new Account();

for (int i=0;i<ac.length;i++){
    
    System.out.print("Enter the account no for ac "+i+" :");
    account_no=input.nextInt();
    System.out.print("Enter the amount for ac "+i+" :");

    amount=input.nextInt();
    ac[i]=new Account(amount,account_no);
    
    
}







        System.out.println("Press 1 to withdraw cash \nPress 2 for balance inquiry \nPress 3 to deposit cash"
                + "\nPress 4 for money transfer");
        int choice,account;
        choice=input.nextInt();
        
        if (choice==1){
            System.out.println("Enter the account no whose amount you want to withdraw ");
            account=input.nextInt();
            System.out.println("the amount withdrawn is "+a.withdraw(account,ac));
            
        }
        
        else if(choice==2){
            System.out.println("Enter the account no who you want to inquire about ");
            account=input.nextInt();
            a.balance_inquiry(account,ac);
        }
        
        else if(choice==3){
            int cash;
            System.out.println("Enter the account no in which you want to deposit ");
           account=input.nextInt();

            System.out.println("Enter the amount you want to deposit in the account ");
            cash=input.nextInt();
            a.deposit(account,cash,ac);
            
           
        }
        
        else if(choice==4){
            int account1;
            System.out.println("Enter first account");
            account=input.nextInt();
            System.out.println("Enter the account you to tranfer money");

            account1=input.nextInt();
           a.transfer(account,account1,ac);
          a.balance_inquiry(account, ac);


        }
        
        else{
            System.out.println("Incorrect choice");
        }
            
    }
}

