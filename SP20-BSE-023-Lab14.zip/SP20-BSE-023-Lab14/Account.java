

package lab14;
import java.util.Scanner;
import java.io.*;

public class Account implements Serializable
{
    
    
    Scanner input=new Scanner(System.in);

    public transient int amount;
    public  transient int account_no;
    public  transient Account ac1,ac2;
    public Account(){
        
        
    }
    
    public int getamount(){
        return amount;
    }
    
    public void setamount(int amount){
        this.amount=amount;
    }
    
    public Account(int amount, int account_no){
        this.account_no=account_no;
        this.amount=amount;
    }
    
    public void setaccount_no(int account_no){
        this.account_no=account_no;
    }
    
    public int getaccount_no(){
        
        return account_no;
    }
    
    
    
    public int withdraw(int account_no,Account ac[]){
        this.account_no=account_no;
        int cash;
        for (int i=0;i<ac.length;i++){
            if(ac[i].getaccount_no()==account_no){
                System.out.println("Enter the amount you want to withdraw ");
                cash=input.nextInt();
                ac[i].setamount(ac[i].getamount()-cash);
                return cash;
            }
        }
        return 0;
    }
    
    public void deposit(int account_no,int amount,Account ac[]){
        for (int i=0;i<ac.length;i++){
            
            if (ac[i].getaccount_no()==account_no){
                ac[i].setamount(amount);
            }
        }
    }
    
    public void transfer(int account_no,int account_no1,Account ac[]){
        int a1=0,a2=0,temp;
        boolean istrue1=false;
        boolean istrue2=false;
        for (int i=0;i<ac.length;i++){
            if (ac[i].getaccount_no()==account_no){
                ac1=ac[i];
                istrue1=true;
                a1=ac[i].getamount();
                
            }
            
        }
        for (int j=0;j<ac.length;j++){
            if (ac[j].getaccount_no()==account_no1){
                ac2=ac[j];
                istrue2=true;
                a2=ac[j].getamount();
            }
        }
        if (istrue1 && istrue2){
    
        temp=a2;
        a2=a1;
        a1=temp;
        ac1.setamount(a2);
        ac2.setamount(a1);
        }
        else{
            System.out.println("The account doesnt exists");
        }
        
    }

    
    public void balance_inquiry(int account_no,Account ac[]){
        this.account_no=account_no;
        for (int i=0;i<ac.length;i++){
            if (ac[i].getaccount_no()==account_no){
                System.out.println("The amount in the account is "+ac[i].getamount());
            }
        }
    }
}
