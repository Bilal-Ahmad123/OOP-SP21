
package assinment_4;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class AddressBook  implements Serializable{
    
    ArrayList <Address> contacts=new ArrayList<>();
    
    transient Scanner  input=new Scanner(System.in);
   public void addcontact(Address address){
       contacts.add(address);
   }
   AddressBook(){
       
   }

   
   public void updatecontact(Address address){
       String f_name,l_name,phone_num,adress;
       int choice;
       System.out.print("1-Change first name or last_name \n2-change Phone_number"
               + "\n3-if you want to change address ");
       choice=input.nextInt();
       switch(choice){
           case 1:
               System.out.print("Enter first name :");
               f_name=input.next();
               System.out.println("Enter last name :");
               l_name=input.next();
               address.setfirstname(f_name);
               address.setLast_name(l_name);
               break;
           case 2:
               System.out.print("Enter phone number :");
               phone_num=input.next();
               address.setPhone_number(phone_num);
               break;
           case 3:
               System.out.print("Enter Address :");
               adress=input.next();
               address.setAddress(adress);
               
       }
       
       
   }
   

   
   public Address searchcontact(String firstname,String lastname){
       for(int i=0;i<contacts.size();i++){
           if (contacts.get(i).getFirst_name().equals(firstname)&&contacts.get(i).getLast_name().equals(lastname)){
               
               return contacts.get(i);
           }
           
       }
       return contacts.get(0);
       
   }
   
   public void deletecontact(Address address){
       contacts.remove(address);
       System.out.println("Contact Deleted");
   }
   
    @Override
   public String toString(){
      for(int i=0;i<contacts.size();i++){
          
      
          System.out.println( "first_name :"+contacts.get(i).getFirst_name()+"\nlast_name :"+contacts.get(i).getLast_name()+"\nPhone_number :"+contacts.get(i).getPhone_number()
                  +"\naddress :"+contacts.get(i).getAddress());
          System.out.println();
      }
      return " ";
   }
}
