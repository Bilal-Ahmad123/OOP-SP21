
package assinment_4;
import java.io.*;

public class Address extends AddressBook implements Serializable{
    
    public String first_name;
    public String last_name;
    public String phone_number;
    public String address;

    public Address(String first_name, String last_name, String phone_number, String address) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone_number = phone_number;
        this.address = address;
    }

    public void setfirstname(String first_name){
        this.first_name=first_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }
    
}
