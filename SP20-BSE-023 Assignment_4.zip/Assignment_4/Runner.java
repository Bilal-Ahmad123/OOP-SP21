
package assinment_4;
import java.io.*;

import java.util.*;

public class Runner {
 
          

    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        Scanner input=new Scanner(System.in);

     AddressBook ab=new AddressBook();
    

         ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("E://bilal.txt"));
         ObjectInputStream ois=new ObjectInputStream(new FileInputStream("E://bilal.txt"));
         
         System.out.print("Enter the number of contacts you want to save :");
         int a=input.nextInt();
         Address ad[]=new Address[a];
         for(int i=0;i<ad.length;i++){
             System.out.print("Enter first name :");
             String f_name=input.next();
             System.out.print("Enter last name :");
             String l_name=input.next();
             System.out.print("Enter Address :");
             String address=input.next();
             System.out.print("Enter phone number :");
             String phone_no=input.next();
             ad[i]=new Address(f_name,l_name,phone_no,address);
             ab.addcontact(ad[i]);
             try{
                 
             
             oos.writeObject(ad[i]);

             }
             catch(IOException e){
                 e.printStackTrace();
             }
             
         }
         
        
         
         


         System.out.println("1(search contact) \n2(delete contact) \n3(update contact)");
         int choice=input.nextInt();
         switch(choice){
             
             case 1:
        System.out.println("Enter the contact you want to search");
        System.out.print("Enter the first name :");
        String f_name=input.next();
        System.out.print("Enter the last name :");
        String l_name=input.next();
         
        
            
          Address ao=ab.searchcontact(f_name, l_name);
         if(ao.first_name.equals(f_name)&&ao.last_name.equals(l_name)){
           System.out.println("Contact found");
        }        
        else{
             System.out.println("Contact doesn't exists");
          }
         break;
         
         
         case 2:
             System.out.print("Enter the first name :");
             String f_name1=input.next();
             System.out.print("Enter the last name :");
             String l_name1=input.next();
             for(int i=0;i<ad.length;i++){
                 Address ap=(Address)ois.readObject();

                 if (ap.first_name.equals(f_name1)&&ap.last_name.equals(l_name1)){
                     ab.deletecontact(ap);
                     break;
                 }
                 
             }
             break;
         
         case 3:
             System.out.print("Enter the first name of the person whose contact you want to update :");
             String f_name2=input.next();
             System.out.print("Enter the last name of the person whose contact you want to update :");
             String l_name2=input.next();
             for(int i=0;i<ad.length;i++){
                 Address ap=(Address)ois.readObject();
                 if (ap.first_name.equals(f_name2)&&ap.last_name.equals(l_name2)){
                     ab.updatecontact(ap);
                     
                     oos.writeObject(ap);
                     System.out.println(ab);
                     break;
                 }
             }
             break;
         default:
             System.out.println("Wrong input");

            
         }
         
         
         
 
       
         
         
        
   
         
         
    }
    
}
