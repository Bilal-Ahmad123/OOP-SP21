
package Lab12;

public interface Association 
{
    void associate();    
}
