
package Lab12;
    import java.util.ArrayList;


public class HumanResource
{

public ArrayList<Association> p=new ArrayList<>();


    public void add(Association  pp)
    {
            p.add(pp);
        
           }
    
    public String delete(String as){
        
        for (int i=0;i<p.size();i++){
            
            if (((Person)p.get(i)).id==as){
                System.out.println("removed");
                p.remove(i);
                
            }
            else{
                return "could'nt remove";
            }
        }
        return "";
        
    }
        
    public void display()
    {
        for(int i=0; i<p.size(); i++)
        {
            System.out.println(p.get(i).toString() + "\n");
        }
    }
}
