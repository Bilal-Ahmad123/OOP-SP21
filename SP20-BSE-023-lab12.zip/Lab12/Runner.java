
package Lab12;

public class Lab12
{
    public static void main(String[] args)
    {
        
        
        HumanResource h1 = new HumanResource();
        
      
        
        h1.add( new Teacher("Muhammad", "1223344") );
        h1.add( new Teacher("Tariq", "1223345") );
        h1.add( new Teacher("Akber", "1223346") );
        h1.add( new Student("Ali", "0023347") );
        h1.add( new Student("Sabih", "0023348") );
        h1.add( new Student("Bilal", "0023348") );
        h1.add( new Student("Zain", "0023348") );
       h1.add( new Student("Arshad", "0023348") );
        h1.add( new Student("Azhar", "0023348") );
        h1.add( new Student("Zain", "0023348") );
       h1.add( new Student("Arshad", "0023348") );
        h1.add( new Student("Azhar", "0023348") );
        h1.delete("1223344");
        h1.display();
      
        

        
       
    }
               
}
    


    

